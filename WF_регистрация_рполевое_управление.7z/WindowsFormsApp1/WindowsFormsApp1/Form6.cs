﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Security.Cryptography;

namespace WindowsFormsApp1
{
    public partial class Form6 : Form
    {
        public static string connectString = @"Data Source =COMP04\sqlexpress; Initial Catalog = prod; Integrated Security = True";

        private SqlConnection myConnection;

        public Form6()
        {
            InitializeComponent();
            myConnection = new SqlConnection(connectString);
            myConnection.Open();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {

            myConnection.Close();
        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }



   



        private void button1_Click(object sender, EventArgs e)
        {

            if (textBox2.Text == textBox3.Text) {
                errorProvider1.Clear();
                errorProvider2.Clear();
                errorProvider3.SetError(textBox2, " ff");
            errorProvider4.SetError(textBox3, "ff ");
                    string query = "INSERT INTO userrs(logins, passwords, id__role) VALUES (@log, @pass, '1')";
                    SqlCommand command = new SqlCommand(query, myConnection);

               
                string pass = textBox2.Text;
               
                string log = textBox1.Text;
                    SqlParameter nameParam = new SqlParameter("@log", log);
                    command.Parameters.Add(nameParam);
                    SqlParameter nameParam1 = new SqlParameter("@pass", pass);
                    command.Parameters.Add(nameParam1);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Поздравляю тебя братишка ты создал аккаунт", "Ураааааааа", MessageBoxButtons.OK, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);
                    this.Close();


                errorProvider1.Clear();
            }


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }
        static bool fn_enable = true;

        private void button2_Click(object sender, EventArgs e)
        {
            if (fn_enable == true)
            {

                textBox3.PasswordChar = (char)0;
                textBox2.PasswordChar = (char)0;
                fn_enable = false;
            }
            else { 
                textBox3.PasswordChar = '*';
                textBox2.PasswordChar = '*';
                fn_enable = true;
            }

        }

        private void errorProvider1_RightToLeftChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            /*реализация проверки пароля*/
            var values = new[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
            var values1 = new[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0" };
            var values2 = new[] { "*", "&", "^", "%", "$", "#", "@", "!", ".", "," };
            var values3 = new[] { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };


            bool a = values2.Any(textBox2.Text.Contains), b = values.Any(textBox2.Text.Contains), с = values1.Any(textBox2.Text.Contains), d = values3.Any(textBox2.Text.Contains);
            if (textBox2.Text.Length < 8)
            {


                errorProvider1.SetError(textBox2, "Длина пароля менее 8 символов");



            }

            else if (b == false)
            {
                errorProvider1.SetError(textBox2, "В вашем пароле нет заглавной буквы");
            }

            else if (с == false)
            {
                errorProvider1.SetError(textBox2, "В вашем пароле нет цифр");
            }

            else if (d == false)
            {
                errorProvider1.SetError(textBox2, "В вашем пароле нет строчных букв");
            }
            else if (a == false)
            {
                errorProvider1.SetError(textBox2, "В вашем пароле нет символов");
            }
            else 

            {
                errorProvider1.SetError (textBox2, "Пароли не совпадают");
                errorProvider2.SetError(textBox3, "Пароли не совпадают");
                
            }
           

        }
    }
}
