﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Security.Cryptography;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {

        public class Image
        {
            public Image(int id, string filename, string title, byte[] data)
            {
                Id = id;
                FileName = filename;
                Title = title;
                Data = data;
            }
            public int Id { get; private set; }
            public string FileName { get; private set; }
            public string Title { get; private set; }
            public byte[] Data { get; private set; }
        }


        public static string connectString = @"Data Source =COMP04\sqlexpress; Initial Catalog = prod; Integrated Security = True";

        private SqlConnection myConnection;

        public Form2()
        {
            InitializeComponent();
            myConnection = new SqlConnection(connectString);
            myConnection.Open();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {

            myConnection.Close();
         
        }

        public string txt {
            get { return label1.Text; }
            set { label1.Text = value; }   
                
                }


        public string txt1
        {
            get { return label2.Text; }
            set { label2.Text = value; }

        }

 

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        public async void button1_Click_1(object sender, EventArgs e)


        {

            byte[] picture;
            string connectionString = @"data source= COMP04\SQLEXPRESS; Database=sdfdfsd;Trusted_Connection=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync();
                string sql = "SELECT Image From Files ";
                SqlCommand command12345 = new SqlCommand(sql, connection);
                using (SqlDataReader reader = await command12345.ExecuteReaderAsync()) ;

                picture = (byte[])command12345.ExecuteScalar();

            }

            MemoryStream st = new MemoryStream();
            st.Write(picture, 0, Convert.ToInt32(picture.Length));
            Bitmap bm = new Bitmap(st, false);
            st.Dispose();
            pictureBox1.Image = bm;







            string query = "select roless.names__roles from roless,userrs where roless.id__role=userrs.id__role and userrs.logins=@logg", query1 = "select roless.description from roless,userrs where roless.id__role=userrs.id__role and userrs.logins=@logg";

            SqlCommand command = new SqlCommand(query, myConnection), command1 = new SqlCommand(query1, myConnection);

            string log = txt1;
            SqlParameter nameParam = new SqlParameter("@logg", log), nameParam1 = new SqlParameter("@logg", log);

            command.Parameters.Add(nameParam);
            command1.Parameters.Add(nameParam1);

            command.ExecuteNonQuery();
            command1.ExecuteNonQuery();



            label3.Text = command.ExecuteScalar().ToString() +"\n"+ command1.ExecuteScalar().ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
    }
}
