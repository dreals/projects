﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Security.Cryptography;

namespace WindowsFormsApp1
{
    


    public partial class Form1 : Form
    {




        public static string connectString = @"Data Source =COMP04\sqlexpress; Initial Catalog = prod; Integrated Security = True";

        private SqlConnection myConnection;

       
        public Form1()
        {
            InitializeComponent();
            myConnection = new SqlConnection(connectString);
            myConnection.Open();

        }

       

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
     
            myConnection.Close();
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                
                string query = "select passwords from userrs where logins=@logg and passwords=@pass",query1 = "select logins from userrs where logins=@logg and passwords=@pass";

                SqlCommand command = new SqlCommand(query, myConnection), command1 = new SqlCommand(query1, myConnection);

                string log = textBox4.Text;
                SqlParameter nameParam = new SqlParameter("@logg", log), nameParam11 = new SqlParameter("@logg", log);

                command.Parameters.Add(nameParam);
                command1.Parameters.Add(nameParam11);

                string pass = textBox44.Text;
                


                SqlParameter nameParam1 = new SqlParameter("@pass", pass), nameParam111 = new SqlParameter("@pass", pass);

                command.Parameters.Add(nameParam1);
                command1.Parameters.Add(nameParam111);

                Form2 form2 = new Form2();
                form2.txt = command.ExecuteScalar().ToString();
                form2.txt1 = command1.ExecuteScalar().ToString();

                form2.Show();

            }

            catch
            {


                try
                {
                    string query = "select logins from userrs where logins=@logg";
                    SqlCommand command = new SqlCommand(query, myConnection);
                    string log = textBox4.Text;
                    SqlParameter nameParam = new SqlParameter("@logg", log);
                    command.Parameters.Add(nameParam);
                    MessageBox.Show(command.ExecuteScalar().ToString() + "\nУ вас введен неправильно пароль", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);

                }


                catch { 
                
                
                        var resss = MessageBox.Show("Вы хотите зарегестрировать новый аккаунт", "Предупреждение", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);

                        if (resss == DialogResult.Yes)
                        {
                            Form6 form6 = new Form6();

                            form6.Show();
                        }
                    

                }




            }


   




        }


       
        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
